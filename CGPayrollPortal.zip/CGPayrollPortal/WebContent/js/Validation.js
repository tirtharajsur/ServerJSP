function validateLoginForm(){
	if(document.LoginForm.associateId.value==""){
		alert("Enter AssociateId");
		return false;;
	}
	else if(LoginForm.password.value==""){
		alert("Enter Password");
		return false;
	}
}

function validateRegistrationForm(){
	if(RegistrationForm.firstName.value==""){
		alert("Enter First Name");
		return false;
	}
	else if(RegistrationForm.lastName.value==""){
		alert("Enter Last Name");
		return false;
	}
	else if(RegistrationForm.emailId.value==""){
		alert("Enter EmailId");
		return false;
	}
	else if(RegistrationForm.designation.value==""){
		alert("Enter Designation");
		return false;
	}
	else if(RegistrationForm.department.value==""){
		alert("Enter Department");
		return false;
	}
	else if(RegistrationForm.pancard.value==""){
		alert("Enter Pancard Number");
		return false;
	}
	else if(RegistrationForm.yearlyInvestmentUnder80C.value==""){
		alert("Enter Yearly Investment");
		return false;
	}
	else if(RegistrationForm.basicSalary.value==""){
		alert("Enter Basic Salary");
		return false;
	}
	else if(RegistrationForm.epf.value==""){
		alert("Enter EPF");
		return false;
	}
	else if(RegistrationForm.companyPf.value==""){
		alert("Enter Company PF");
		return false;
	}
	else if(RegistrationForm.bankName.value==""){
		alert("Enter Bank Name");
		return false;
	}
	else if(RegistrationForm.accountNumber.value==""){
		alert("Enter Account Number");
		return false;
	}
	else if(RegistrationForm.ifscCode.value==""){
		alert("Enter Bank IFSC Code");
		return false;
	}
	else if(RegistrationForm.communication.value==""){
		alert("Enter Mode of Communication");
		return false;
	}
}
function validatePassword(){
	if(chanePasswordForm.password.value.length>=6){
		if(changePasswordForm.password.value.search(/[0-9]/)!= -1 &&
				changePasswordForm.password.value.search(/[A-Z]/)!=1 &&
				changePasswordForm.password.value.search(/[!@#$%^&*()_+]/)!= -1){
			return true;
		}
		else{
			alert("Password must contain atleast 1 number 1 UPPERCASE letter and  1 LOWERCASE character");
			return false;
		}
	}
	else{
		alert("minimum of 6 characters");
		return false;
	}
}
function checkSame(){
	if(changePasswprdForm.password.value != changePasswordForm.confirmPassword.value){
		alert("Password and Confirm Password did not match");
		return false;
	}
}

function toggleShow(){
		  var x = document.getElementById("pass");
		  if (x.type === "password") {
		    x.type = "text";
		  } else {
		    x.type = "password";
		  }
}

