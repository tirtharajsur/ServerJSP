package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices{
private AssociateDAO  associateDao;
public PayrollServicesImpl() {
associateDao = new AssociateDAOImpl(); 
}
public PayrollServicesImpl(AssociateDAO associateDao) {
	super();
	this.associateDao = associateDao;
}

	@Override
	public int acceptAssociateDetails(Associate associate) {
	associate = associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setNetSalary((int) (12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf()));
		associateDao.update(associate);
		return associate.getSalary().getNetSalary();
//		return 12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details not found for Id"+associateId);
		return associate;
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		
		return associateDao.findAll();
	}
	@Override
	public double calculateGrossSalary(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setGrossSalary ((int) (associate.getSalary().getBasicSalary()
				+0.3*associate.getSalary().getBasicSalary()*2
				+0.25*associate.getSalary().getBasicSalary()
				+0.2*associate.getSalary().getBasicSalary()
				+associate.getSalary().getCompanyPf()
				+associate.getSalary().getEpf()));
		
		associateDao.update(associate);
		return associate.getSalary().getGrossSalary();
		/*
		 * return (associate.getSalary().getBasicSalary()
		 * +0.3*associate.getSalary().getBasicSalary()*2
		 * +0.25*associate.getSalary().getBasicSalary()
		 * +0.2*associate.getSalary().getBasicSalary()
		 * +associate.getSalary().getCompanyPf() +associate.getSalary().getEpf());
		 */
	}
}
