function sayHello() {
	document.getElementById("msg").innerHTML="<font color = 'orange'>Hello World on browser"
	console.log("Hello World on browser")
}

function sayHello2(){
	alert("Do you wanna leave the page?")
}