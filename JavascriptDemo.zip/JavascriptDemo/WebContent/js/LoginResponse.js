function sayYaay() {
	document.getElementById("msg").innerHTML="<font color = 'orange'>Yaay!!You are now logged in!!"
	console.log("Yaay!!You are now logged in!!")
}